var searchData=
[
  ['hanzitopinyin',['HanziToPinyin',['../classcom_1_1hyphenate_1_1util_1_1_hanzi_to_pinyin.html',1,'com::hyphenate::util']]]
];
