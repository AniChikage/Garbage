var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuvzå",
  1: "cdefhilmnpstuvz",
  2: "c",
  3: "abcdefghijlmoprstuz",
  4: "acdefgimnprsu",
  5: "v",
  6: "å"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enumvalues",
  6: "pages"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "命名空间",
  3: "函数",
  4: "变量",
  5: "枚举值",
  6: "页"
};

