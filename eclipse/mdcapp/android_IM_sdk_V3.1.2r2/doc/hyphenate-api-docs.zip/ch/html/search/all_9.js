var searchData=
[
  ['joinchatroom',['joinChatRoom',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_chat_room_manager.html#af2d592b0801dbc333c0c60bd551e150d',1,'com::hyphenate::chat::EMChatRoomManager']]],
  ['joingroup',['joinGroup',['../classcom_1_1hyphenate_1_1chat_1_1_e_m_group_manager.html#af8bb90ad806ecbbc0f536bd9c285cb98',1,'com::hyphenate::chat::EMGroupManager']]]
];
